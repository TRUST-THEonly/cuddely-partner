//
//  RKISO8601DateFormatter.h
//  RestKit
//
//  Created by Christopher Swasey on 1/20/12.
//  Copyright (c) 2009-2012 RestKit. All rights reserved.
//

#import "ISO8601DateFormatter.h"

@interface RKISO8601DateFormatter : ISO8601DateFormatter

@end
