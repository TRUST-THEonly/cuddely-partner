//
//  Task.m
//  RKCatalog
//
//  Created by Blake Watters on 4/21/11.
//  Copyright (c) 2009-2012 RestKit. All rights reserved.
//

#import "Task.h"

@implementation Task

@dynamic name;
@dynamic taskID;
@dynamic assignedUserID;
@dynamic assignedUser;

@end
