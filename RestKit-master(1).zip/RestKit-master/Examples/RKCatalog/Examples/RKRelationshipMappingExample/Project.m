//
//  Project.m
//  RKCatalog
//
//  Created by Blake Watters on 4/21/11.
//  Copyright (c) 2009-2012 RestKit. All rights reserved.
//

#import "Project.h"

@implementation Project

@synthesize projectID = _projectID;
@synthesize name = _name;
@synthesize description = _description;
@synthesize user = _user;
@synthesize tasks = _tasks;

@end
